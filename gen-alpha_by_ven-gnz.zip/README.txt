4k Workshop Entry
===================


A very small example that you can examine and modify to build your
very first browser 4k intro.

Author:     ven-gnz

Techniques: lmad1 workshop code (Javascript, WebGL, SoundBox, Closure
            Compiler, Pnginator)

This production uses the SoundBox synthesizer tracker by Marcus
Geelnard: (http://sb.bitsnbites.eu/).