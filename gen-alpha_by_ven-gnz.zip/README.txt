4k Workshop Entry - gen-alpha
===================


Author:     ven-gnz

Techniques: lmad1 workshop code (Javascript, WebGL, SoundBox, Closure
            Compiler, Pnginator)

This production uses the SoundBox synthesizer tracker by Marcus
Geelnard: (http://sb.bitsnbites.eu/).