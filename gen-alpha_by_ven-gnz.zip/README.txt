4k Workshop Example
===================

<Edit this file to describe your own production...>
<Don't forget the title line.>
<Mention any tools by others that you used, like lmad1 and SoundBox.>
<Delete these hints in angle brackets. Otherwise, fully free form & content>

A very small example that you can examine and modify to build your
very first browser 4k intro.

Author:     <Your own (nick)name here>

            <and contact details, if you want to provide some>

Techniques: lmad1 workshop code (Javascript, WebGL, SoundBox, Closure
            Compiler, Pnginator)

This production uses the SoundBox synthesizer tracker by Marcus
Geelnard: (http://sb.bitsnbites.eu/).


Greets
-------------------

<... or other messages you want to attach to your compo entry>
